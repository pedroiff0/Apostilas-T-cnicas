#include <iostream>
using namespace std;
/*
Faça um programa que defina a estrutura de um registro com base em sua carteirinha escolar.
*/

struct date {
  int dia;
  int mes;
  int ano;
};

struct horario {
  int horas;
  int minutos;
  int segundos;
};

struct carteirinha_escolar {
  string nome;
  string matricula;
  string curso;
  int ano;
  date data_validade;
};

int main() {
  carteirinha_escolar c;
  c.data_validade.dia = 5;
  c.data_validade.mes = 12;
  c.data_validade.ano = 2021;
}