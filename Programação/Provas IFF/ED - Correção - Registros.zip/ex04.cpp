#include <iostream>
using namespace std;
/*
Faça um programa que defina a estrutura de um registro com base em sua carteirinha escolar.
*/

struct date {
  int dia;
  int mes;
  int ano;
};

struct horario {
  int horas;
  int minutos;
  int segundos;
};

struct consulta_medica {
  string paciente;
  string medico;
  string local;
  date data_consulta;
  horario hora_consulta;
};

int main() {
  consulta_medica cm;

  cout << "Informe o nome do paciente: ";
  cin >> cm.paciente;

  cout << "Informe o nome do médico: ";
  cin >> cm.medico;

  cout << "Informe o local da consulta: ";
  cin >> cm.local;

  cout << "Informe a data do agendamento (d m a): ";
  cin >> cm.data_consulta.dia;
  cin >> cm.data_consulta.mes;
  cin >> cm.data_consulta.ano;

  cout << "Informe o horário do agendamento (h m): ";
  cin >> cm.hora_consulta.horas;
  cin >> cm.hora_consulta.minutos;
  cm.hora_consulta.segundos = 0;

  cout << "Dados do Agendamento:" << endl;
  cout << "Paciente: " << cm.paciente << endl;
  cout << "Médico: " << cm.medico << endl;
  cout << "Local: " << cm.local << endl;
  cout << "Data: " << cm.data_consulta.dia << "/" << cm.data_consulta.mes << "/" << cm.data_consulta.ano << " - " << cm.hora_consulta.horas << ":" << cm.hora_consulta.minutos << ":" << cm.hora_consulta.segundos;
}