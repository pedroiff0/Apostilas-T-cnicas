#include <iostream>
using namespace std;

int main() {
  int numeros[10];

  for (int i = 0; i < 10; i++) {
    cout << "Informe o " << i + 1 << "º número: ";
    cin >> numeros[i];
  }

  int numero_pesquisado;

  cout << "Informe um número a ser pesquisado: ";
  cin >> numero_pesquisado;

  bool encontrado = false;

  for (int i = 0; i < 10; i++) {
    if (numero_pesquisado == numeros[i]) {
      encontrado = true;
    }
  }

  if (encontrado) {
    cout << "Número encontrado.";
  } else {
    cout << "Número não encontrado.";
  }

}