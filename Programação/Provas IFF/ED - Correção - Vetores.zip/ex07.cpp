#include <iostream>
using namespace std;

int main() {
  int t = 4;
  int votacao[t];
  string times[] = {"BOT", "FLA", "FLU", "VAS"};

  for (int i = 0; i < t; i++) {
    votacao[i] = 0;
  }

  int voto;

  do {
    cout << "Escolha um time:\n" << endl;
    cout << "1 - Botafogo" << endl;
    cout << "2 - Flamengo" << endl;
    cout << "3 - Fluminense" << endl;
    cout << "4 - Vasco" << endl;
    cout << "0 - Sair" << endl;
    cin >> voto;
    if (voto != 0) {
      votacao[voto - 1]++;
    }
  } while (voto != 0);

  for (int i = 0; i < 4; i++){
    cout << times[i] << " - ";
    for (int j = 0; j < votacao[i]; j++) {
      cout << "*";
    }
    cout << endl;
  }
  
}