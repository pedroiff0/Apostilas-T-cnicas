#include <iostream>
using namespace std;

int main() {
  int t = 10;
  int numeros[t];

  for (int i = 0; i < t; i++) {
    cout << "Informe o " << i + 1 << "º número: ";
    cin >> numeros[i];
  }

  int i_final = t - 1;

  //inverter
  for (int i = 0; i < t / 2; i++) {
    int aux = numeros[i];
    numeros[i] = numeros[i_final];
    numeros[i_final] = aux;
    i_final--;
  }

  for (int i = 0; i < t; i++) {
    cout << numeros[i] << "\t";
  }

}