#include <iostream>
using namespace std;

int main() {
  double notas[10];

  for (int i = 0; i < 10; i++) {
    cout << "Informe a " << i + 1 << "ª nota: ";
    cin >> notas[i];
  }

  int notas_acima_media = 0;

  for (int i = 0; i < 10; i++) {
    if (notas[i] > 6) {
      notas_acima_media++;
    }
  }

  cout << "Quantidade de notas acima da média: " << notas_acima_media;

}