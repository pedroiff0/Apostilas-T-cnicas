#include <iostream>
using namespace std;

int main() {
  int numeros[10];

  //preencher
  for (int i = 0; i < 10; i++) {
    cout << "Informe um nº: ";
    cin >> numeros[i];
  }

  int soma = 0;

  //percorrer
  for (int i = 0; i < 10; i++) {
    soma += numeros[i];
  }

  cout << "Soma: " << soma << endl;

}