#include <iostream>
using namespace std;

int main() {
  int numeros[10];

  for (int i = 0; i < 10; i++) {
    cout << "Informe um nº: ";
    cin >> numeros[i];
  }

  int qtd_zeros = 0, qtd_pares = 0, qtd_impares = 0;
  int maior_par, maior_impar;
  for (int i = 0; i < 10; i++) {
    if (numeros[i] == 0) {
      qtd_zeros++;
    } else if (numeros[i] % 2 == 0) {
      qtd_pares++;
      maior_par = numeros[i];
    } else {
      qtd_impares++;
      maior_impar = numeros[i];
    }
  }

  for (int i = 0; i < 10; i++) {
    if (numeros[i] % 2 == 0 && numeros[i] > maior_par) {
      maior_par = numeros[i];
    }
    if (numeros[i] % 2 != 0  && numeros[i] > maior_impar) {
      maior_impar = numeros[i];
    }
  }

  cout << "Qtd de zeros: " << qtd_zeros << endl;
  cout << "Qtd de pares: " << qtd_pares << endl;
  cout << "Qtd de ímpares: " << qtd_impares << endl;
  cout << "Maior par: " << maior_par << endl;
  cout << "Maior ímpar: " << maior_impar << endl;

}