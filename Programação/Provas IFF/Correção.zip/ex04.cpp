#include <iostream>
using namespace std;

int main() {
  int t = 5, n = 1;
  int matriz[t][t];

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      matriz[l][c] = n++;
    }
  }
  cout << "Matriz Original: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      cout << matriz[l][c] << "\t";
    }
    cout << endl;
  }

  for (int c = 0; c < t; c++) {
    int aux = matriz[1][c];
    matriz[1][c] = matriz[4][c];
    matriz[4][c] = aux;
  }

  for (int c = 0; c < t; c++) {
    int aux = matriz[0][c];
    matriz[0][c] = matriz[3][c];
    matriz[3][c] = aux;
  }

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l == c) {
        int aux = matriz[l][c];
        matriz[l][c] = matriz[l][t - 1 - l];
        matriz[l][t - 1 - l] = aux;
      }
    }
  }

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      cout << matriz[l][c] << "\t";
    }
    cout << endl;
  }

}