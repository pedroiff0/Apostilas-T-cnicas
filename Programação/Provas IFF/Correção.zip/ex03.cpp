#include <iostream>
using namespace std;

int main() {
  int t = 5, n = 1;
  int matriz[t][t];

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      matriz[l][c] = n++;
    }
  }

  cout << "Diagonal Principal: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l == c){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

  cout << "\nTriângulo Superior - Diagonal Principal: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l < c){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

  cout << "\nTriângulo Inferior - Diagonal Principal: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l > c){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

  cout << "\nExceto Diagonal Principal: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l != c){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

  cout << "\nDiagonal Secundária: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l + c == t - 1){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

   cout << "\nTriângulo Superior - Secundária: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l + c < t - 1){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

   cout << "\nTriângulo Inferior - Secundária: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l + c > t - 1){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

   cout << "\nExceto Diagonal Secundária: " << endl;
  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l + c != t - 1){
        cout << matriz[l][c] << "\t";
      } else {
        cout << "_" << "\t";
      }
    }
    cout << endl;
  }

}