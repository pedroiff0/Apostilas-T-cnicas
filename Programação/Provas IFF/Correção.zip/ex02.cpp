#include <iostream>
using namespace std;

int main() {
  int t = 10;
  int matriz[t][t];

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (l == c || l + c == t - 1) {
        matriz[l][c] = 1;
      } else {
        matriz[l][c] = 0;
      }
    }
  }

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      cout << matriz[l][c] << "\t";
    }
    cout << endl;
  }

}