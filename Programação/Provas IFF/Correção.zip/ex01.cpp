#include <iostream>
using namespace std;

int main() {
  int t = 3, n = 1;
  int maior, l_maior, c_maior;
  int matriz[t][t];

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      matriz[l][c] = n;
      n++;
    }
  }

  matriz[1][1] = 100;

  maior = matriz[0][0];
  l_maior = 0;
  c_maior = 0;

  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      if (matriz[l][c] > maior) {
        maior = matriz[l][c];
        l_maior = l;
        c_maior = c;
      }
    }
  }

  cout << "O maior elemento está na posição: " << l_maior << "X" << c_maior << endl;





  for (int l = 0; l < t; l++) {
    for (int c = 0; c < t; c++) {
      cout << matriz[l][c] << "\t";
    }
    cout << endl;
  }

}